package aracKiralamaSistemi;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Giris extends JFrame {
    private JTextField userText;
    private JPasswordField passwordText;

    public Giris() {
        setTitle("Personel Girişi");
        setSize(350, 300); // Boyutu artırdık
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new JPanel();
        add(panel);
        placeComponents(panel);
        setLocationRelativeTo(null); // Ortaya yerleştirme
    }

    private void placeComponents(JPanel panel) {
        panel.setLayout(null);

        // Başlık Label'ı
        JLabel titleLabel = new JLabel("Araç Kiralama Sistemi");
        titleLabel.setBounds(60, 5, 220, 25);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(titleLabel);

        // Resim Label'ı
        ImageIcon imageIcon = new ImageIcon("C:\\Users\\hakan\\Downloads\\rentacar.jpg");
        Image img = imageIcon.getImage(); // Resmi al
        Image newImg = img.getScaledInstance(260, 100, Image.SCALE_SMOOTH); // Boyutlandır
        JLabel imageLabel = new JLabel(new ImageIcon(newImg)); // Yeni boyutlandırılmış resmi set et
        imageLabel.setBounds(10, 30, 320, 100); // Resmin konumunu ayarlayın
        panel.add(imageLabel);

        JLabel isimLabel = new JLabel("Kullanıcı Adı:");
        isimLabel.setBounds(10, 140, 80, 25);
        panel.add(isimLabel);

        userText = new JTextField(20);
        userText.setBounds(100, 140, 165, 25);
        panel.add(userText);

        JLabel passwordLabel = new JLabel("Şifre:");
        passwordLabel.setBounds(10, 170, 80, 25);
        panel.add(passwordLabel);

        passwordText = new JPasswordField(20);
        passwordText.setBounds(100, 170, 165, 25);
        panel.add(passwordText);

        JButton loginButton = new JButton("Giriş");
        loginButton.setBounds(10, 210, 80, 25); // Butonun konumunu ayarlayın
        panel.add(loginButton);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String userName = userText.getText();
                String password = new String(passwordText.getPassword());
                if ("deneme".equals(userName.trim()) && "1234".equals(password.trim())) {
                    // AnaSayfa'yı aç ve Giris'i kapat
                    AnaSayfa anaSayfa = new AnaSayfa();
                    anaSayfa.setVisible(true); // AnaSayfa'nın görünürlüğünü sağla
                    dispose(); // Giris'i kapat
                } else {
                    JOptionPane.showMessageDialog(null, "Hatalı kullanıcı adı veya şifre");
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Giris giris = new Giris();
            giris.setVisible(true); // Arayüzün görünürlüğünü burada ayarladık
        });
    }
}
