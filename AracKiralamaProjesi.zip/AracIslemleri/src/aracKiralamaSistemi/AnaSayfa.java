package aracKiralamaSistemi;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AnaSayfa extends JFrame {
    private JPanel contentPane;
    private JPanel cardPanel;
    private CardLayout cardLayout;

    public AnaSayfa() {
        setTitle("Araç Kiralama Sistemi");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null); // Ortada açılması için

        // Ana panel ve layout ayarı
        contentPane = new JPanel(new BorderLayout());
        setContentPane(contentPane);

        // Sol panel (Menü) ayarı
        JPanel menuPanel = new JPanel();
        menuPanel.setBackground(new Color(0, 102, 102));
        menuPanel.setPreferredSize(new Dimension(200, getHeight()));
        menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS)); // Dikey yerleştirme
        contentPane.add(menuPanel, BorderLayout.WEST);

        // Başlık etiketi
        JLabel titleLabel = new JLabel("Araç Kiralama");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        menuPanel.add(titleLabel);
        menuPanel.add(Box.createRigidArea(new Dimension(0, 20))); // Boş alan ekle

        // "Araç İşlemleri" butonu ekleniyor
        JButton aracIslemleriButton = createMenuButton("Araç İşlemleri");
        menuPanel.add(aracIslemleriButton);

        // CardLayout ile değiştirilebilir alan için panel ayarı
        cardPanel = new JPanel();
        cardLayout = new CardLayout();
        cardPanel.setLayout(cardLayout);
        contentPane.add(cardPanel, BorderLayout.CENTER);

        // Ana sayfa ve araç işlemleri panellerini CardLayout'a ekle
        JPanel anaPanel = new JPanel();  // Varsayılan ana panel
        anaPanel.add(new JLabel("Ana Sayfa"));
        cardPanel.add(anaPanel, "AnaPanel");

        JPanel aracIslemleriPanel = new AracIslemleri(); // AracIslemleri paneli
        cardPanel.add(aracIslemleriPanel, "AracIslemleriPanel");

        // Butona tıklama işlemi
        aracIslemleriButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cardPanel, "AracIslemleriPanel");
            }
        });
    }

    private JButton createMenuButton(String text) {
        JButton button = new JButton(text);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setPreferredSize(new Dimension(180, 40));
        button.setBackground(new Color(0, 153, 153));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder());
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setFont(new Font("Arial", Font.PLAIN, 16));

        // Hover etkisi
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(0, 204, 204));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(0, 153, 153));
            }
        });

        return button;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            AnaSayfa frame = new AnaSayfa();
            frame.setVisible(true);
        });
    }
}


