package aracKiralamaSistemi;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

public class AracIslemleri extends JPanel {
    private JTable aracTable;
    private DefaultTableModel tableModel;
    private JTextField tfPlaka, tfMarka, tfModel, tfPaket, tfYil, tfKM, tfFiyat;
    private JComboBox<String> cbYakit, cbVites, cbSinif;
    private JCheckBox cbMusait, cbKirada;
    private static final String FILE_PATH = "C:\\Users\\hakan\\OneDrive\\Masaüstü\\kullanici\\araci.txt";

    public AracIslemleri() {
        setLayout(new BorderLayout());

        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc;

        // Form bileşenlerini oluşturma (Plaka, Marka, Model, Paket, Yıl, KM, Fiyat, Yakıt, Vites, Araç Sınıfı, Durum)
        // (Aynı kod, formPanel içine eklenecek. Kod tekrarından kaçınmak için burada eklemiyorum.)

        GridBagConstraints gbcPlaka = new GridBagConstraints();
        gbcPlaka.insets = new Insets(10, 5, 5, 5);
        gbcPlaka.fill = GridBagConstraints.HORIZONTAL;
        gbcPlaka.gridx = 0;
        gbcPlaka.gridy = 0;
        formPanel.add(new JLabel("Plaka:"), gbcPlaka);
        gbcPlaka.gridx = 1;
        tfPlaka = new JTextField(10);
        formPanel.add(tfPlaka, gbcPlaka);

        // Marka
        GridBagConstraints gbcMarka = new GridBagConstraints();
        gbcMarka.insets = new Insets(10, 5, 5, 5);
        gbcMarka.gridx = 0;
        gbcMarka.gridy = 1;
        formPanel.add(new JLabel("Marka:"), gbcMarka);
        gbcMarka.gridx = 1;
        tfMarka = new JTextField(10);
        formPanel.add(tfMarka, gbcMarka);

        // Model
        GridBagConstraints gbcModel = new GridBagConstraints();
        gbcModel.insets = new Insets(10, 5, 5, 5);
        gbcModel.gridx = 0;
        gbcModel.gridy = 2;
        formPanel.add(new JLabel("Model:"), gbcModel);
        gbcModel.gridx = 1;
        tfModel = new JTextField(10);
        formPanel.add(tfModel, gbcModel);

        // Paket
        GridBagConstraints gbcPaket = new GridBagConstraints();
        gbcPaket.insets = new Insets(10, 5, 5, 5);
        gbcPaket.gridx = 0;
        gbcPaket.gridy = 3;
        formPanel.add(new JLabel("Paket:"), gbcPaket);
        gbcPaket.gridx = 1;
        tfPaket = new JTextField(10);
        formPanel.add(tfPaket, gbcPaket);

        // Yıl
        GridBagConstraints gbcYil = new GridBagConstraints();
        gbcYil.insets = new Insets(10, 5, 5, 5);
        gbcYil.gridx = 0;
        gbcYil.gridy = 4;
        formPanel.add(new JLabel("Yıl:"), gbcYil);
        gbcYil.gridx = 1;
        tfYil = new JTextField(10);
        formPanel.add(tfYil, gbcYil);

        // KM
        GridBagConstraints gbcKM = new GridBagConstraints();
        gbcKM.insets = new Insets(10, 5, 5, 5);
        gbcKM.gridx = 0;
        gbcKM.gridy = 5;
        formPanel.add(new JLabel("KM:"), gbcKM);
        gbcKM.gridx = 1;
        tfKM = new JTextField(10);
        formPanel.add(tfKM, gbcKM);

        // Fiyat
        GridBagConstraints gbcFiyat = new GridBagConstraints();
        gbcFiyat.insets = new Insets(10, 5, 5, 5);
        gbcFiyat.gridx = 0;
        gbcFiyat.gridy = 6;
        formPanel.add(new JLabel("Fiyat:"), gbcFiyat);
        gbcFiyat.gridx = 1;
        tfFiyat = new JTextField(10);
        formPanel.add(tfFiyat, gbcFiyat);

        // Yakıt
        GridBagConstraints gbcYakit = new GridBagConstraints();
        gbcYakit.insets = new Insets(10, 5, 5, 5);
        gbcYakit.gridx = 0;
        gbcYakit.gridy = 7;
        formPanel.add(new JLabel("Yakıt:"), gbcYakit);
        gbcYakit.gridx = 1;
        cbYakit = new JComboBox<>(new String[]{"Benzin", "Dizel", "Elektrik"});
        formPanel.add(cbYakit, gbcYakit);

        // Vites
        GridBagConstraints gbcVites = new GridBagConstraints();
        gbcVites.insets = new Insets(10, 5, 5, 5);
        gbcVites.gridx = 0;
        gbcVites.gridy = 8;
        formPanel.add(new JLabel("Vites:"), gbcVites);
        gbcVites.gridx = 1;
        cbVites = new JComboBox<>(new String[]{"Manuel", "Otomatik"});
        formPanel.add(cbVites, gbcVites);

        // Araç Sınıfı
        GridBagConstraints gbcSinif = new GridBagConstraints();
        gbcSinif.insets = new Insets(10, 5, 5, 5);
        gbcSinif.gridx = 0;
        gbcSinif.gridy = 9;
        formPanel.add(new JLabel("Araç Sınıfı:"), gbcSinif);
        gbcSinif.gridx = 1;
        cbSinif = new JComboBox<>(new String[]{"Ekonomik", "Orta", "Lüks"});
        formPanel.add(cbSinif, gbcSinif);

        // Durum
        GridBagConstraints gbcDurum = new GridBagConstraints();
        gbcDurum.insets = new Insets(10, 5, 5, 5);
        gbcDurum.gridx = 0;
        gbcDurum.gridy = 10;
        formPanel.add(new JLabel("Durum:"), gbcDurum);
        gbcDurum.gridx = 1;
        JPanel durumPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        cbMusait = new JCheckBox("Müsait");
        cbKirada = new JCheckBox("Kirada");
        durumPanel.add(cbMusait);
        durumPanel.add(cbKirada);
        formPanel.add(durumPanel, gbcDurum);

        add(formPanel, BorderLayout.WEST);

        // Tablo oluşturma
        tableModel = new DefaultTableModel();
        tableModel.setColumnIdentifiers(new String[]{"Plaka", "Marka", "Model", "Paket", "Yıl", "Yakıt", "Vites", "KM", "Fiyat", "Durum"});
        aracTable = new JTable(tableModel){
        	@Override
            public boolean isCellEditable(int row, int column) {
                return false; // Tüm hücreler düzenlenemez
            }
        };
        
        // siralama
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tableModel);
        aracTable.setRowSorter(sorter);
        
        JScrollPane tableScrollPane = new JScrollPane(aracTable);
        add(tableScrollPane, BorderLayout.CENTER);
        
        

        // Buton paneli
        JPanel buttonPanel = new JPanel();
        JButton btnKaydet = new JButton("Kaydet");
        JButton btnDüzenle = new JButton("Düzenle");
        JButton btnSil = new JButton("Sil");

        // Kaydet butonu
        btnKaydet.addActionListener(e -> {
        	if (!isFormValid()) return;
            String plaka = tfPlaka.getText();
            String marka = tfMarka.getText();
            String model = tfModel.getText();
            String paket = tfPaket.getText();
            String yil = tfYil.getText();
            String km = tfKM.getText();
            String fiyat = tfFiyat.getText();
            String yakit = (String) cbYakit.getSelectedItem();
            String vites = (String) cbVites.getSelectedItem();
            String sinif = (String) cbSinif.getSelectedItem();
            String durum = cbMusait.isSelected() ? "Müsait" : cbKirada.isSelected() ? "Kirada" : "Mevcut Değil";

            tableModel.addRow(new Object[]{plaka, marka, model, paket, yil, yakit, vites, km, fiyat, durum});
            saveToFile(); // Veriyi tabloya ekledikten sonra dosyaya kaydet
            resetForm();
        });

        // Düzenle butonu
        btnDüzenle.addActionListener(e -> {
            int selectedRow = aracTable.getSelectedRow();
            if (selectedRow != -1) {
            	if (!isFormValid()) return;
            	
                tfPlaka.setText(tableModel.getValueAt(selectedRow, 0).toString());
                tfMarka.setText(tableModel.getValueAt(selectedRow, 1).toString());
                tfModel.setText(tableModel.getValueAt(selectedRow, 2).toString());
                tfPaket.setText(tableModel.getValueAt(selectedRow, 3).toString());
                tfYil.setText(tableModel.getValueAt(selectedRow, 4).toString());
                tfKM.setText(tableModel.getValueAt(selectedRow, 7).toString());
                tfFiyat.setText(tableModel.getValueAt(selectedRow, 8).toString());
                cbYakit.setSelectedItem(tableModel.getValueAt(selectedRow, 5).toString());
                cbVites.setSelectedItem(tableModel.getValueAt(selectedRow, 6).toString());
                // Durum
                String durum = tableModel.getValueAt(selectedRow, 9).toString();
                cbMusait.setSelected(durum.equals("Müsait"));
                cbKirada.setSelected(durum.equals("Kirada"));
            } else {
                JOptionPane.showMessageDialog(this, "Lütfen düzenlemek için bir satır seçin.", "Uyarı", JOptionPane.WARNING_MESSAGE);
            }
        });
        
        

        // Sil butonu
        btnSil.addActionListener(e -> {
            int selectedRow = aracTable.getSelectedRow();
            if (selectedRow != -1) {
                tableModel.removeRow(selectedRow);
                saveToFile(); // Tablodaki veriyi sildikten sonra dosyayı güncelle
            } else {
                JOptionPane.showMessageDialog(this, "Lütfen silmek için bir satır seçin.", "Uyarı", JOptionPane.WARNING_MESSAGE);
            }
        });

        buttonPanel.add(btnKaydet);
        buttonPanel.add(btnDüzenle);
        buttonPanel.add(btnSil);
        add(buttonPanel, BorderLayout.SOUTH);

        loadFromFile(); // Uygulama açıldığında dosyadan verileri yükle
    }
    
    
    private boolean isFormValid() {
        if (tfPlaka.getText().isEmpty() || tfMarka.getText().isEmpty() || tfModel.getText().isEmpty() ||
            tfPaket.getText().isEmpty() || tfYil.getText().isEmpty() || tfKM.getText().isEmpty() || tfFiyat.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Lütfen tüm alanları doldurun.", "Uyarı", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        try {
            int yil = Integer.parseInt(tfYil.getText());
            int km = Integer.parseInt(tfKM.getText());
            double fiyat = Double.parseDouble(tfFiyat.getText());

            if (yil <= 0 || km <= 0 || fiyat <= 0) {
                JOptionPane.showMessageDialog(this, "Yıl, KM ve Fiyat alanlarına pozitif sayısal değerler girilmelidir.", "Uyarı", JOptionPane.WARNING_MESSAGE);
                return false;
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Yıl, KM ve Fiyat alanlarına geçerli sayısal değerler girilmelidir.", "Uyarı", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        
     // Plaka benzersiz mi kontrolü
        String plaka = tfPlaka.getText(); // Plakayı formdan al
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if (tableModel.getValueAt(i, 0).toString().equals(plaka)) {
                JOptionPane.showMessageDialog(this, "Bu plaka zaten mevcut!", "Uyarı", JOptionPane.WARNING_MESSAGE);
                return false;
            }
        }
        return true;
    }

    private void resetForm() {
        tfPlaka.setText("");
        tfMarka.setText("");
        tfModel.setText("");
        tfPaket.setText("");
        tfYil.setText("");
        tfKM.setText("");
        tfFiyat.setText("");
        cbYakit.setSelectedIndex(0);
        cbVites.setSelectedIndex(0);
        cbSinif.setSelectedIndex(0);
        cbMusait.setSelected(false);
        cbKirada.setSelected(false);
    }

    private void saveToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                for (int j = 0; j < tableModel.getColumnCount(); j++) {
                    writer.write(tableModel.getValueAt(i, j).toString());
                    if (j < tableModel.getColumnCount() - 1) writer.write(",");
                }
                writer.newLine();
            }
            JOptionPane.showMessageDialog(this, "Veri başarıyla kaydedildi.", "Başarılı", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Veri kaydı başarısız oldu.", "Hata", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split(",");
                tableModel.addRow(values);
            }
            JOptionPane.showMessageDialog(this, "Veriler başarıyla yüklendi.", "Başarılı", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Veri yüklemesi başarısız oldu.", "Hata", JOptionPane.ERROR_MESSAGE);
        }
    }
}









