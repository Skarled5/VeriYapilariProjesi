/**
 * 
 */
/**
 * 
 */
module AracIslemleri {
	requires java.desktop;
}